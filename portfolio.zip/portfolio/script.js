function validateForm()
{
    let name=document.getElementById("name").value;
    let email=document.getElementById("email").value;
    let message=document.getElementById("message").value;

    if(name=="")
    {
        alert("Please Enter Name");
        return false;
    }

    if(email=="")
    {
        alert("Please Enter Email");
        return false;
    }

    if(message=="")
    {
        alert("Please Enter Message");
        return false;
    }

    alert("Form Submitted Successfully");

    return true;
}